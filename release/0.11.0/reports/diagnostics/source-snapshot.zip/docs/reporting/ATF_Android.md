# Contractul publicării Android și al componentelor

Publicarea oferă o prezentare autonomă a scopului, intrărilor și rezultatelor evaluate. Consumatorul furnizează semantica domeniului și înregistrările tipizate; biblioteca comună furnizează prezentarea prin API-ul public.

## Responsabilități

```mermaid
flowchart LR
    ACTION[Acțiune reală] -->|produce| OBS[Observație]
    OBS -->|confruntă prin oracol| ASSERT[Comparație evaluată]
    ACTION -->|aparține| CHECK[Checkpoint]
    ASSERT -->|aparține| CHECK
    IMAGE[PNG original] -->|aparține| CHECK
    CHECK -->|publică prin API| HTML[HTML autonom]
```

<details>
<summary>Legendă: proprietatea datelor</summary>

Acțiunea, observația, comparația și captura sunt fapte distincte, asociate aceleiași invocări și stări. Rendererul proiectează rezultatul evaluat fără să execute din nou oracolul sau să deducă succesul dintr-o imagine.

</details>

| Owner | Contract |
|---|---|
| Consumer | Captură, extragere stare, oracol independent, reguli, selecție și compoziție. |
| Bibliotecă | Tipuri neutre, tabele, disclosure, timing și vizualizatorul imaginilor. |
| Acceptor | Integritate, proprietate, completitudine și verificarea interactivă a scopului declarat. |

## Invocarea și fazele

| Nivel | Conținut obligatoriu |
|---|---|
| Invocare | Identitate reală de clasă, metodă și parametri, cu profilul efectiv. |
| Setup | Intrări și precondiții evaluate; pregătirea nu înlocuiește verificarea corpului. |
| Corp | Stare anterioară, input, stare rezultată, expected independent, actual și verdict. |
| Teardown | Curățarea efectivă și cauza secundară, fără înlocuirea erorii inițiale. |
| Populație | Cazuri, partide, perechi, mutări și comparații delimitate ca unități distincte. |

- Fiecare invocare reală rămâne identificabilă, inclusiv parametrizările cu același nume.
- Setup-ul, contextul sau o statistică agregată nu generează invocări PASS fictive.
- Rezultatele PASS, FAIL, ERROR și SKIP sunt păstrate distinct.
- Captura parțială la eșec păstrează ultimul context sigur și cauza originală.
- Rezultatul JUnit fără comparații capturate nu permite reconstruirea lor ulterioară prin text.

## Acțiune, observație și rezultat

Tabelul de acțiuni păstrează operația expediată, ținta semantică, așteptarea, observația, timpul și rezultatul. Tabelul de comparații păstrează ASSERTION, EXPECTED, ACTUAL și RESULT pentru evaluarea executată o singură dată.

- ADB este sursa dispatch-ului Android, iar UI Automator furnizează ierarhia.
- Browserul care inspectează HTML-ul este auditorul raportului.
- O comandă acceptată și o tranziție semantică corectă au criterii distincte.
- OBSERVE descrie o stare fără inventarea unui input.
- HTTP, SQL, comparațiile de componentă și acțiunile UI folosesc suprafața semantică a faptului real.
- Titlurile și rezumatele nu substituie comparațiile detaliate.

### Corpuri integrale și bugetul de afișare

Previzualizarea aserțiunilor și plafonul corpurilor sunt setări independente. [EvidenceTextParts](../../atf-test-android/src/main/java/atf/android/evidence/text/EvidenceTextParts.java) împarte textul deja redactat în părți consecutive care respectă bugetul efectiv, fără să separe o pereche Unicode.

- Fiecare corp păstrează ownerul, hash-ul sursei și ordinea `part i/N`; concatenarea părților reconstruiește integral proiecția permisă.
- Împărțirea nu mărește plafonul și nu reevaluează comparațiile. Un caracter care nu încape în buget produce refuz explicit, fără trunchiere ascunsă.
- Același mecanism publică intrările componentelor, expected/actual integrale și anexele text Android; testele includ coada unei ierarhii mai mari decât plafonul.

### Republicare fără interacțiuni Android

[CapturedAndroidFlow](../../atf-test-android/src/test/java/atf/android/e2e/support/replay/CapturedAndroidFlow.java) citește manifestul existent prin contractul read-only al publicării. Păstrează comparațiile, verdicturile, checkpoint-urile și intervalele originale; refuză verdicturi necunoscute, artefacte care părăsesc ownerul și timpi atribuiți altui flux.

Republicarea are eticheta `offline-republication` și proveniență explicită. HTML-ul nou nu devine execuție Android nouă; manifestul original rămâne neschimbat, iar browserul verifică separat noua prezentare.
- O atribuire falsă a driverului este refuzată chiar când celelalte valori coincid.

## Capturi și proprietate

- Fiecare checkpoint publicat poate conține PNG-ul original al întregului ecran fizic, cu orientarea și marginile păstrate.
- Analiza unei regiuni poate deriva o imagine separată, fără înlocuirea capturii originale.
- PNG-urile sunt încorporate Base64 în HTML; payload-urile identice pot fi canonice, cu referințe exacte pentru fiecare checkpoint.
- Statusul local al checkpoint-ului se păstrează; rezultatul final nu recolorează retrospectiv toate stările.
- Dacă între capturi au loc mai multe acțiuni, fereastra observată este declarată explicit.
- Componentele fără dispozitiv folosesc date de stare și comparații, fără capturi Android fabricate.

Vizualizatorul păstrează proporțiile imaginii și oferă acces la dimensiunea originală. Revenirea păstrează proprietarul curent, disclosure-urile, derularea și focusul; verificarea consumerului confruntă payload-ul original cu referința exactă.

## Conținut autonom și bugete

HTML-ul trebuie să permită înțelegerea verificării fără acces la checkout: regula, unitățile, intrarea comparată, observația și limita afirmației rămân asociate proprietarului.

[Politica prezentării](ATF_Presentation.md) deține selecția invocărilor, grupurile, fragmentele și bugetele. Captura originală și valorile care justifică rezultatul sunt date obligatorii; diagnosticul opțional are încadrare explicită.

Un hash dovedește identitatea octeților, fără a substitui oracolul de domeniu. Un link extern sau un rezumat al replay-ului nu înlocuiește comparațiile necesare scopului publicat.

### Captura anexelor

- [Captura text](../../atf-test-android/src/main/java/atf/android/evidence/text/CapturedTextEvidence.java) citește o singură dată octeții și decodează strict UTF-8; fingerprint-ul identifică originalul, iar corpul publicat trece prin redactarea bibliotecii.
- Publicatorul încorporează manifestul, anexele declarate de checkpoint-uri și intrările suplimentare, deduplicând corpurile identice; datele necitibile sunt refuzate înaintea sesiunii.
- Încorporarea la publicare este etichetată ca atare și nu reconstruiește timpul capturii Android.

## Timp și status

[Contractul temporal](ATF_PhaseTiming.md) deține intervalele originale, axele și tratarea jurnalelor incomplete. [Predarea rezultatelor](ATF_Handoff.md) deține acceptanța unui scop și identitatea republicării.

- Eșecul unei acțiuni, comparații sau capturi nu este anulat printr-o finalizare ulterioară cu succes.
- Verdictul funcțional și rezultatul publicării sunt fapte distincte.
- Zero invocări, date obligatorii lipsă sau numai SKIP nu închid un scop drept verificat.

## Implementare și verificare

Datele capturate, publicarea și auditul au contracte separate:

| Responsabil | Contract |
|---|---|
| [AndroidUiFlowTrace](../../atf-test-android/src/test/java/atf/android/e2e/support/AndroidUiFlowTrace.java) | Păstrează ordinea și proprietatea datelor înaintea publicării. |
| [AndroidUiFlowReportPublisher](../../atf-test-android/src/test/java/atf/android/e2e/support/AndroidUiFlowReportPublisher.java) | Proiectează checkpoint-urile prin API-ul UI al bibliotecii și gestionează sesiunea de publicare. |
| [AndroidUiFlowReportAudit](../../atf-test-android/src/test/java/atf/android/e2e/support/AndroidUiFlowReportAudit.java) | Confruntă raportul rezultat cu checkpoint-urile, acțiunile, comparațiile, intervalele și PNG-urile capturate; refuză asocierile incomplete sau divergente. |

Controalele urmăresc proprietarul exact, multiplicitatea, ultima comparație, ordinea fragmentelor și bytes-ii PNG. Căutarea globală a unei valori sau a unui hash nu demonstrează asocierea ei cu scenariul corect.

- Cititorul este verificat și pe marcaje cu atribute suplimentare, păstrând aceleași etichete, ordine și imagini; delimitarea urmărește nodurile DOM, fără a depinde de serializarea unui tag.
- Controlul negativ schimbă legătura imaginii din checkpoint-ul ales, folosind poziția exactă a nodului în sursă. Restul documentului rămâne intact, astfel încât refuzul să demonstreze defectul de asociere vizat.
- Limita de previzualizare se citește din configurația activă și se confruntă cu metadatele comparațiilor publicate. Testele temporizării verifică efectul configurării, fără a fixa valoarea implicită a bibliotecii.

[Politica de prezentare](ATF_Presentation.md) · [Timing original](ATF_PhaseTiming.md) · [Auditul publicării](ATF_Audit.md) · [Responsabilități](../feedback/README.md)
