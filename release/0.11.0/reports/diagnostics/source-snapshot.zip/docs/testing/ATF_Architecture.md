# Arhitectura testării

## Pe scurt

Nivelul unui test rezultă din limita pe care o verifică. Colecția stabilește scopul și costul selecției, iar mediul stabilește dacă execuția folosește numai JVM sau și un dispozitiv Android.

## Alegerea nivelului minim

```mermaid
flowchart LR
    CONTRACT[Contract] -->|delimitează| LIMIT[Limită observabilă]
    LIMIT -->|alege| LAYER[Nivel minim]
    LAYER -->|controlează| FIXTURE[Pregătire izolată]
    FIXTURE -->|exercită| CHECK[Verificare independentă]
    CHECK -->|justifică| RESULT[Rezultat]
```

<details>
<summary>Legendă: contractul precede instrumentul</summary>

Nivelul depinde de colaborarea reală necesară verificării. Un fișier arhivat, un raport sau numele pachetului nu transformă un test într-o execuție E2E.

</details>

| Nivel | Contract verificat | Pregătire potrivită | Limită |
|---|---|---|---|
| Unitar — `unit` | Politică pură, model, calcul, parsare sau formatare | Intrări tipizate, ceas controlat, fără servicii | Nu certifică integrarea dintre module. |
| Componentă — `component` | API-ul public al unui modul ori adaptor | Dubluri controlate, date locale, fișiere temporare | Nu certifică o călătorie nouă în aplicația instalată. |
| Integrare — `integration` | Colaborarea reală dintre componente sau module | Bibliotecile fizice, configurație și resurse controlate | Nu repetă toate variantele deja acoperite la nivel inferior. |
| Cap la cap — `e2e` | Parcurs observabil în aplicația Android | Dispozitiv rezervat, aplicație identificată, stare inițială explicită | Cere acțiuni și observații noi; se activează separat. |

O funcție auxiliară, un constructor de date, un încărcător sau un oracol este suport. O clasă executabilă dintr-un pachet de suport își declară propriul nivel.

## Matricea executabilă Maven

Tabelul reflectă adnotările claselor executabile, inclusiv adnotările compuse. „—” înseamnă absența unei clase declarate la acel nivel; nu impune crearea unei suite artificiale.

| Modul | Unitar | Componentă | Integrare | E2E | Responsabilitate |
|---|---|---|---|---|---|
| `atf-validation` | Da | Da | — | — | Reguli de validare și evaluarea contractelor publice. |
| `atf-test-android` | Da | Da | Da | Da | Timp, ADB simulat, oracole, integrarea raportării și parcursuri Android reale. |
| `atf-tests` | Da | Da | Da | — | Contractele adaptoarelor, binarele comune și guvernanța proiectului. |

[Verificarea matricei](../../atf-tests/src/test/java/atf/tests/governance/source/TestLayerGovernanceTest.java) confruntă acest tabel cu sursele curente. Fiecare clasă executabilă Maven are exact una dintre `@AtfUnitTest`, `@AtfComponentTest`, `@AtfIntegrationTest` și `@AtfE2eTest`, direct sau printr-o adnotare compusă.

Declarațiile sunt extrase prin parserul JDK, independent de indentare și de poziția adnotării față de modificatori. Metodele aparțin tipului care le declară, containerele `@Nested` au rol explicit, iar modulele păstrează identitatea rădăcinilor Maven; [contractul sintactic](../governance/README.md#declarațiile-testelor) delimitează această inspecție de execuția JUnit.

- **Biblioteci comune:** Core, Reporting, Console, Mock și [Test Kit](../../lib/README.TestKit.md) sunt [biblioteci binare](../platform/README.md). Testele lor native rămân la responsabilul comun; proiectul verifică separat integrarea binarelor și adaptoarele sale.

| Contract reprezentativ | Sursă |
|---|---|
| Ceas și intervale | [AndroidPhaseClockTest](../../atf-test-android/src/test/java/atf/android/evidence/timing/AndroidPhaseClockTest.java) |
| Adaptor fără dispozitiv | [AdbClientContractTest](../../atf-test-android/src/test/java/atf/android/AdbClientContractTest.java) |
| Binar și integrarea consumatorului | [CoreReportingConsumerContractTest](../../atf-tests/src/test/java/atf/tests/publishing/CoreReportingConsumerContractTest.java) |
| Parcurs Android | [WhistLabGameplayE2eTest](../../atf-test-android/src/test/java/atf/android/e2e/gameplay/WhistLabGameplayE2eTest.java) |
| Calitatea surselor și documentelor | [AtfQualityGovernanceSuite](../../atf-tests/src/test/java/atf/tests/governance/AtfQualityGovernanceSuite.java) |

## Suite primare și selecții focalizate

[Catalogul executabil](../../config/atf-test-suites.json) atribuie fiecărei clase Maven exact o suită primară din modulul și nivelul ei. Selectorii primari folosesc pachetele și eticheta nivelului, cu motorul Jupiter; o clasă nouă intră în selecție fără completarea manuală a unei liste.

| Rol | Responsabilitate | Regula de agregare |
|---|---|---|
| Primar | Populația completă a unui nivel dintr-un modul | Fiecare clasă executabilă are exact un proprietar primar. |
| Focalizat | Submulțime explicită a unuia sau mai multor părinți primari | Se execută pentru diagnostic ori un scop restrâns; nu adaugă din nou cazurile în totalul primar. |

- **Acoperire:** părinții includ întreaga populație a selecției focalizate înaintea filtrelor de canal. Suita primară nu permite excluderi; filtrarea unei selecții offline păstrează proprietarul primar al canalului.

- **Guvernanță:** [controlul selecțiilor](../../atf-tests/src/test/java/atf/tests/governance/suites/SuiteOwnershipGovernanceTest.java) confruntă declarațiile, rolurile și selecțiile. Refuză clase omise, proprietari multipli, nivel greșit și selecții neînregistrate ori fără părinte; corecția modifică intrarea, fără eliminarea testului.

- **Nivel:** guvernanța este o selecție focalizată care traversează mai multe niveluri. Verificările și publicatoarele care consumă jurnale externe au nivel de integrare și precondiții proprii; recitirea ori republicarea nu devine componentă autonomă sau execuție Android.

## Motorul și interfața în Gradle

Motorul folosește JUnit JVM prin [configurația proprie](../../whist-lab-app/game-core/build.gradle). Nu depinde de Test Kit și nu pretinde adnotările Maven.

[ai-lab](../../whist-lab-app/ai-lab/README.md) este modul JVM consumat numai la testarea motorului. `:ai-lab:check` execută contractele Java locale și uneltele Node.js, cu date legale construite fără arhivă. Classpath-ul Java local exclude motorul, Android și ATF; experimentele păstrate sub `experiments` sunt excluse din sursele principale.

| Zonă | Nivel semantic | Ce verifică | Execuție |
|---|---|---|---|
| Reguli și scor | Unitar sau componentă, după API-ul exercitat | Legalitate, levate, puncte, serii și limite | JVM, fără Android. |
| Sesiune și restaurare | Componentă | Comenzi, tranziții și respingerea unei stări inconsistente | Situații legale controlate. |
| Politici AI | Componentă | Observația permisă, decizia și proprietățile justificate independent | [Proiectarea testelor AI](ATF_AiComponents.md). |
| Costul deciziei | Componentă și integrare între observație și cele două API-uri AI | Lucru, CPU, legalitate și determinism pe poziții generate | [Profil JVM explicit](../ai/ATF_CostQualification.md); fără latență Android sau verdict strategic. |
| Partidă simulată | Integrare de domeniu | Colaborarea politicilor cu motorul și oracolul până la scorul final | Distribuții și locuri declarate. |
| Geometrie și texte Android | Unitar sau componentă JVM | Dimensiuni, regiuni, localizare și modele de prezentare | [Testele aplicației](../../whist-lab-app/app/src/test/java/ro/whistlab/app/). |
| Interacțiune în aplicația instalată | E2E | Legătura dintre comandă, stare, captură și scor | [Infrastructura Android](ATF_Android.md). |

Un turneu este o evaluare de politică, cu populație și criterii proprii. Numărul partidelor sau victoria nu înlocuiesc așteptarea independentă a unei regresii de componentă.

## Axe independente

| Axă | Întrebarea la care răspunde | Sursa contractului |
|---|---|---|
| Nivel | Ce limită este verificată? | Acest ghid și declarațiile executabile. |
| Colecție | De ce și când rulăm selecția? | [Catalogul colecțiilor](ATF_Collections.md). |
| Mediu | Ce resurse reale sunt necesare? | JVM, copie temporară sau dispozitiv rezervat explicit. |
| Canal | Ce observație verificăm? | Interfață, API ori combinația declarată. |
| Publicare | Ce invocări și date prezentăm? | [Contractul datelor publicate](../reporting/ATF_Audit.md). |

`quick`, `regression`, `strategy` și `learning` sunt scopuri de selecție. Republicarea unui jurnal Android este o verificare a adaptorului de publicare; nu execută din nou interacțiunile istorice.

## Construcția și întreținerea unei verificări

Mutarea unei verificări la un nivel mai mic păstrează invariantul și oracolul. Se extrage o responsabilitate observabilă; numărul mai mic de teste Android nu justifică pierderea unui refuz ori a unei tranziții.

1. Formulați proprietatea și limita ei înaintea alegerii instrumentului.
2. Alegeți nivelul minim care observă defectul fără a împrumuta verdictul implementării.
3. Pregătiți o stare validă și un rezultat așteptat independent.
4. Verificați cazul nominal, refuzul relevant și vecinul sănătos.
5. Declarați separat resursele, bugetul, selecția și condițiile de activare.
6. Actualizați documentul contractului și eliminați suprapunerile fără proprietăți distincte.

Rezultatele se păstrează în afara surselor. Testele unitare nu sunt obligate să producă prezentarea unui parcurs E2E; volumul publicării urmează scopul verificării.

## Mutarea verificărilor din E2E în componente

| Proprietate extrasă | Componenta potrivită | Ce rămâne pe Android |
|---|---|---|
| Geometrie, intersecții și centrare | Măsurători tipizate, extreme legale, text mărit și vecini care încalcă o singură limită. | Fontul efectiv, insets, ținta tactilă și aceeași compoziție în raster. |
| Interpretarea ierarhiei | XML controlat: stare validă, nod lipsă, duplicat, regiune tăiată și document malformat. | Captura proaspătă după acțiune și identitatea ecranului observat. |
| Tranziție sau reluare | Porturi mici, motorul real și evenimente livrate controlat, inclusiv după anulare. | Comanda prin controlul afișat, callback-urile și persistența platformei. |
| Publicare | Date capturate, comparații și eșecuri originale; Extent/fallback și mutații ale rezultatului. | Revizia interactivă a HTML-ului rămâne audit de raport, cu propriul mediu. |

- **Echivalență:** mapați cazul vechi la cazurile noi prin proprietate și identitate; păstrați situația nominală, refuzul și vecinul sănătos.
- **Izolare:** fixture-ul schimbă intrarea ori observația controlată, iar așteptarea provine din regulă sau oracol independent. Nu folosiți rezultatul implementării ca expected.
- **Ordine:** temporizarea injectată verifică succesiunea evenimentelor; un somn real sau un retry nu înlocuiește dovada opririi la eșec.
- **Selecție:** rulați entry point-ul real al suitei și confruntați [inventarul execuției](ATF_Collections.md#inventarul-unei-selecții); fișierul mutat trebuie compilat și selectat efectiv.

Componentele oracolului și sanity-ul nativ califică frontiere diferite. [Ghidul afișajului](ATF_Display.md) deține selecția nativă rămasă, iar [guvernanța schimbării testelor](../governance/ATF_TestChanges.md) deține retragerea cazurilor fără pierderea contractului.

[Colecții și comenzi](ATF_Collections.md) · [Verificarea partidei](ATF_Gameplay.md) · [Guvernanța calității](../governance/README.md)
