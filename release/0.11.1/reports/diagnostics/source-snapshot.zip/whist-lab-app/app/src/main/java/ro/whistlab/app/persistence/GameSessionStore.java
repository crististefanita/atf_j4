package ro.whistlab.app.persistence;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import ro.whistlab.core.config.AiDifficulty;
import ro.whistlab.core.model.Card;
import ro.whistlab.core.config.GameConfig;
import ro.whistlab.core.rules.GameMode;
import ro.whistlab.core.session.GamePhase;
import ro.whistlab.core.session.GameSession;
import ro.whistlab.core.model.PlayedCard;
import ro.whistlab.core.session.ScoreHistory;
import ro.whistlab.core.model.Suit;
import ro.whistlab.core.model.Trump;

/** Versioned, synchronous checkpoint storage for resuming a local match after process death. */
public final class GameSessionStore {
    private static final String PREFERENCES = "whist_lab_game";
    private static final String SAVE_KEY = "current_session_v1";
    private static final int VERSION = 8;

    private static boolean readZeroGame(JSONObject root) throws JSONException {
        if (SavedNumbers.integer(root, "version") < 8 && !root.has("allowZeroGame")) return false;
        Object value = root.get("allowZeroGame");
        if (!(value instanceof Boolean)) throw new JSONException("Boolean required: allowZeroGame");
        return (Boolean) value;
    }

    private GameSessionStore() { }

    public static void save(Context context, GameSession game) throws IOException {
        save(context, game, true);
    }

    public static void save(Context context, GameSession game, boolean rankingEligible) throws IOException {
        save(context, game, rankingEligible, Long.toUnsignedString(game.config().seed()));
    }

    public static void save(Context context, GameSession game, boolean rankingEligible, String matchId) throws IOException {
        try {
            JSONObject root = encode(game.saveState());
            root.put("rankingEligible", rankingEligible);
            root.put("matchId", matchId);
            boolean stored = preferences(context).edit().putString(SAVE_KEY, root.toString()).commit();
            if (!stored) throw new IOException("Android could not save the current game");
        } catch (JSONException failure) {
            throw new IOException("Could not encode the current game", failure);
        }
    }

    public static boolean rankingEligible(Context context) {
        try {
            String json = preferences(context).getString(SAVE_KEY, null);
            return json == null || new JSONObject(json).optBoolean("rankingEligible", true);
        } catch (JSONException invalid) { throw new IllegalStateException("Invalid saved eligibility", invalid); }
    }

    public static String matchId(Context context) {
        try {
            String encoded = preferences(context).getString(SAVE_KEY, null);
            String id = encoded == null ? java.util.UUID.randomUUID().toString()
                    : new JSONObject(encoded).optString("matchId", java.util.UUID.randomUUID().toString());
            if (id.isBlank() || id.length() > 128) throw new IllegalStateException("Invalid saved match identity");
            return id;
        } catch (JSONException invalid) { throw new IllegalStateException("Invalid saved match identity", invalid); }
    }

    public static GameSession load(Context context) {
        String encoded = preferences(context).getString(SAVE_KEY, null);
        if (encoded == null || encoded.isBlank()) return null;
        return fromJson(encoded);
    }

    public static GameSession fromJson(String encoded) {
        try {
            JSONObject root = new JSONObject(encoded);
            if (SavedNumbers.integer(root, "version") < 1 || SavedNumbers.integer(root, "version") > VERSION) {
                throw new IllegalArgumentException("Unsupported saved-game version " + SavedNumbers.integer(root, "version"));
            }
            GameSession.SaveState state=decode(root);
            return SavedNumbers.integer(root, "version")>=2?GameSession.restoreComplete(state):GameSession.restore(state);
        } catch (JSONException | IllegalArgumentException | ArithmeticException failure) {
            throw new IllegalStateException("Saved game is invalid and cannot be resumed", failure);
        }
    }

    public static final class UnsupportedSavedMode extends IllegalStateException {
        public UnsupportedSavedMode(String mode) { super("Unsupported saved mode: " + mode); }
    }

    private static GameMode savedMode(String name) {
        try {
            return GameMode.valueOf(name);
        } catch (IllegalArgumentException unknown) {
            throw new UnsupportedSavedMode(name);
        }
    }

    public static void clear(Context context) {
        preferences(context).edit().remove(SAVE_KEY).commit();
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }

    public static JSONObject encode(GameSession.SaveState state) throws JSONException {
        JSONObject root = new JSONObject();
        int remaining=state.players().stream().mapToInt(p->p.hand().size()).sum();
        // A resumed v1 hand cannot invent its missing early history. Keep its legacy
        // marker until the next fresh deal. The score ledger is independent of this marker.
        boolean complete = state.history().size() == state.handSize() * state.config().playerCount() - remaining;
        root.put("version", complete ? VERSION : 1);
        root.put("playerCount", state.config().playerCount());
        root.put("mode", state.config().mode().name());
        root.put("difficulty", state.config().aiDifficulty().name());
        root.put("seed", state.config().seed());
        root.put("streakBonuses", state.config().streakBonuses());
        root.put("streakBonusPoints", state.config().streakBonusPoints());
        root.put("streakPenaltyPoints", state.config().streakPenaltyPoints());
        root.put("allowZeroGame", state.config().allowZeroGame());
        root.put("phase", state.phase().name());
        root.put("handIndex", state.handIndex());
        root.put("handSize", state.handSize());
        root.put("dealerSeat", state.dealerSeat());
        root.put("biddingSeat", state.biddingSeat());
        root.put("currentSeat", state.currentSeat());
        root.put("bidsSubmitted", state.bidsSubmitted());
        root.put("bidTotal", state.bidTotal());
        root.put("trump", state.trump().name());
        root.put("lastTrickWinnerSeat", state.lastTrickWinnerSeat());

        JSONArray players = new JSONArray();
        for (GameSession.PlayerState player : state.players()) {
            JSONObject item = new JSONObject();
            item.put("seat", player.seat());
            item.put("name", player.name());
            item.put("human", player.human());
            item.put("hand", encodeCards(player.hand()));
            item.put("bid", player.bid() == null ? JSONObject.NULL : player.bid());
            item.put("tricksWon", player.tricksWon());
            item.put("totalScore", player.totalScore());
            item.put("streak", player.streak());
            item.put("streakPoints", player.streakPoints());
            players.put(item);
        }
        root.put("players", players);
        ScoreHistory ledger = state.scoreHistory();
        JSONObject scores = new JSONObject();
        scores.put("priorHands", ledger.priorHands());
        scores.put("opening", new JSONArray(ledger.openingTotals()));
        JSONArray rows = new JSONArray();
        for (List<Integer> totals : ledger.closingTotals()) rows.put(new JSONArray(totals));
        scores.put("hands", rows);
        JSONArray bids = new JSONArray();
        for (List<Integer> contracts : ledger.recordedBids()) bids.put(new JSONArray(contracts));
        scores.put("bids", bids);
        JSONArray tricks = new JSONArray();
        for (List<Integer> won : ledger.recordedTricks()) tricks.put(new JSONArray(won));
        scores.put("tricks", tricks);
        root.put("scores", scores);
        root.put("currentTrick", encodeTrick(state.currentTrick()));
        root.put("lastTrick", encodeTrick(state.lastTrick()));
        root.put("history", encodeTrick(state.history()));
        root.put("turnedCard", state.turnedCard() == null ? JSONObject.NULL
                : encodeCards(java.util.Collections.singletonList(state.turnedCard())).getJSONObject(0));
        return root;
    }

    private static GameSession.SaveState decode(JSONObject root) throws JSONException {
        GameConfig config = new GameConfig(SavedNumbers.integer(root, "playerCount"),
                savedMode(root.getString("mode")),
                AiDifficulty.fromStoredName(root.getString("difficulty")), SavedNumbers.seed(root),
                root.optBoolean("streakBonuses", false), SavedNumbers.optionalInteger(root, "streakBonusPoints", 5),
                SavedNumbers.integer(root, "version") >= 6 || root.has("streakPenaltyPoints")
                        ? SavedNumbers.integer(root, "streakPenaltyPoints") : 5,
                readZeroGame(root));
        JSONArray encodedPlayers = root.getJSONArray("players");
        List<GameSession.PlayerState> players = new ArrayList<>(encodedPlayers.length());
        for (int index = 0; index < encodedPlayers.length(); index++) {
            JSONObject player = encodedPlayers.getJSONObject(index);
            Object encodedBid = player.get("bid");
            Integer bid = encodedBid == JSONObject.NULL ? null : SavedNumbers.integer(player, "bid");
            players.add(new GameSession.PlayerState(SavedNumbers.integer(player, "seat"), player.getString("name"),
                    player.getBoolean("human"), decodeCards(player.getJSONArray("hand")), bid,
                    SavedNumbers.integer(player, "tricksWon"), SavedNumbers.integer(player, "totalScore"),SavedNumbers.optionalInteger(player, "streak", 0),SavedNumbers.optionalInteger(player, "streakPoints", 0)));
        }
        List<PlayedCard> current = decodeTrick(root.getJSONArray("currentTrick"));
        List<PlayedCard> last = decodeTrick(root.getJSONArray("lastTrick"));
        List<PlayedCard> history = new ArrayList<>(last); history.addAll(current);
        if (root.has("history")) history = decodeTrick(root.getJSONArray("history"));
        Card turned = null;
        if (root.has("turnedCard") && !root.isNull("turnedCard")) {
            JSONObject item = root.getJSONObject("turnedCard");
            turned = new Card(Suit.valueOf(item.getString("suit")), SavedNumbers.integer(item, "rank"));
        }
        return new GameSession.SaveState(config, GamePhase.valueOf(root.getString("phase")),
                SavedNumbers.integer(root, "handIndex"), SavedNumbers.integer(root, "handSize"), SavedNumbers.integer(root, "dealerSeat"),
                SavedNumbers.integer(root, "biddingSeat"), SavedNumbers.integer(root, "currentSeat"), SavedNumbers.integer(root, "bidsSubmitted"),
                SavedNumbers.integer(root, "bidTotal"), Trump.valueOf(root.getString("trump")),
                SavedNumbers.integer(root, "lastTrickWinnerSeat"), players,
                current, last, history, turned, decodeScoreHistory(root, players));
    }

    private static ScoreHistory decodeScoreHistory(JSONObject root, List<GameSession.PlayerState> players) throws JSONException {
        if (SavedNumbers.integer(root, "version") < 4 && !root.has("scores")) return null;
        JSONObject scores = root.getJSONObject("scores");
        JSONArray hands = scores.getJSONArray("hands");
        List<List<Integer>> rows = new ArrayList<>(hands.length());
        for (int i = 0; i < hands.length(); i++) rows.add(scoreVector(hands.getJSONArray(i)));
        List<List<Integer>> bids = new ArrayList<>();
        boolean settled = GamePhase.SCORE.name().equals(root.getString("phase"));
        if (SavedNumbers.integer(root, "version") >= 5 || scores.has("bids")) {
            JSONArray contracts = scores.getJSONArray("bids");
            for (int i = 0; i < contracts.length(); i++) bids.add(scoreVector(contracts.getJSONArray(i)));
            if (settled && bids.isEmpty()) throw new JSONException("Missing completed hand bids");
        } else if (settled) {
            bids.add(players.stream().map(GameSession.PlayerState::bid).collect(java.util.stream.Collectors.toList()));
        }
        List<List<Integer>> tricks = new ArrayList<>();
        if (SavedNumbers.integer(root, "version") >= 7 || scores.has("tricks")) {
            JSONArray won = scores.getJSONArray("tricks");
            for (int i = 0; i < won.length(); i++) tricks.add(scoreVector(won.getJSONArray(i)));
            if (settled && tricks.isEmpty()) throw new JSONException("Missing completed hand tricks");
        } else if (settled) {
            tricks.add(players.stream().map(GameSession.PlayerState::tricksWon).collect(java.util.stream.Collectors.toList()));
        }
        return new ScoreHistory(scoreInt(scores.get("priorHands")), scoreVector(scores.getJSONArray("opening")), rows, bids, tricks);
    }

    private static List<Integer> scoreVector(JSONArray values) throws JSONException {
        List<Integer> row = new ArrayList<>(values.length());
        for (int i = 0; i < values.length(); i++) row.add(scoreInt(values.get(i)));
        return row;
    }

    private static int scoreInt(Object value) throws JSONException {
        if (!(value instanceof Integer)) throw new JSONException("Score history requires integer values");
        return (Integer) value;
    }

    private static JSONArray encodeCards(List<Card> cards) throws JSONException {
        JSONArray encoded = new JSONArray();
        for (Card card : cards) {
            JSONObject item = new JSONObject();
            item.put("suit", card.suit().name());
            item.put("rank", card.rank());
            encoded.put(item);
        }
        return encoded;
    }

    private static List<Card> decodeCards(JSONArray encoded) throws JSONException {
        List<Card> cards = new ArrayList<>(encoded.length());
        for (int index = 0; index < encoded.length(); index++) {
            JSONObject item = encoded.getJSONObject(index);
            cards.add(new Card(Suit.valueOf(item.getString("suit")), SavedNumbers.integer(item, "rank")));
        }
        return cards;
    }

    private static JSONArray encodeTrick(List<PlayedCard> trick) throws JSONException {
        JSONArray encoded = new JSONArray();
        for (PlayedCard play : trick) {
            JSONObject item = new JSONObject();
            item.put("seat", play.seat());
            item.put("suit", play.card().suit().name());
            item.put("rank", play.card().rank());
            encoded.put(item);
        }
        return encoded;
    }

    private static List<PlayedCard> decodeTrick(JSONArray encoded) throws JSONException {
        List<PlayedCard> trick = new ArrayList<>(encoded.length());
        for (int index = 0; index < encoded.length(); index++) {
            JSONObject item = encoded.getJSONObject(index);
            trick.add(new PlayedCard(SavedNumbers.integer(item, "seat"),
                    new Card(Suit.valueOf(item.getString("suit")), SavedNumbers.integer(item, "rank"))));
        }
        return trick;
    }
}
