package ro.whistlab.app.highscores;

import static atf.gradle.audit.assertions.GradleAssertions.*;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONObject;
import org.junit.Test;
import ro.whistlab.app.localization.WhistUiText;
import ro.whistlab.app.persistence.GameSessionStore;
import ro.whistlab.core.config.AiDifficulty;
import ro.whistlab.core.config.GameConfig;
import ro.whistlab.core.rules.GameMode;
import ro.whistlab.core.rules.GameRules;
import ro.whistlab.core.rules.HowToPlay;
import ro.whistlab.core.session.GamePhase;
import ro.whistlab.core.session.GameSession;

public class HighScoreRepositoryComponentTest extends atf.gradle.audit.GradleAuditedTest {
    private static final HighScores.Profile PROFILE = new HighScores.Profile(GameMode.ROMANIAN_WHIST, 4, AiDifficulty.HARD, true, 10, 10);
    private static final class Memory implements HighScoreRepository.Storage {
        String json; int writes; boolean fail;
        public String read() { return json; }
        public void write(String value) throws IOException { if (fail) throw new IOException("disk full"); json = value; writes++; }
    }

    @Test public void everyGameTypeStartsWithTenMarkedSamplesAndReloadDoesNotReseed() throws Exception {
        var disk = new Memory(); var repository = new HighScoreRepository(disk, new Random(7));
        var first = repository.boards();

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "disk", disk, "first", first, "repository", repository);
        assertEquals("first.size() must equal GameMode.values().length", GameMode.values().length, first.size());
        for (var board : first) {
            assertEquals("board.entries().size() must equal 10", 10, board.entries().size());
            assertTrue("board.entries().stream().allMatch(HighScores.Entry::sample) must hold", board.entries().stream().allMatch(HighScores.Entry::sample));
            assertTrue("board.entries().stream().map(HighScores.Entry::score).distinct().count() > 1 must hold", board.entries().stream().map(HighScores.Entry::score).distinct().count() > 1);
        }
        String bytes = disk.json; int writes = disk.writes;
        assertEquals("new HighScoreRepository(disk, new Random(999)).boards() must equal first", first, new HighScoreRepository(disk, new Random(999)).boards());
        assertEquals("disk.json must equal bytes", bytes, disk.json); assertEquals("disk.writes must equal writes", writes, disk.writes);
    }

    @Test public void rankingGrowsToTwentyThenRetainsTheBestScoresIncludingAiAndNegativeScores() {
        var data = new HighScores(); data.ensure(PROFILE, new Random(1));
        for (int game = 0; game < 8; game++) {
            var entries = new ArrayList<HighScores.Entry>();
            for (int seat = 0; seat < 4; seat++) entries.add(new HighScores.Entry("Ana", game * 100 + seat, seat != 0, false, "game-" + game, seat, game));

            atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "data", data, "entries", entries, "game", game);
            assertTrue("data.record(PROFILE, \"game-\" + game, entries, new Random(2)) must hold", data.record(PROFILE, "game-" + game, entries, new Random(2)));
            assertEquals("data.boards.get(PROFILE.key()).entries().size() must equal Math.min(10 + 4 * (game + 1), 20)", Math.min(10 + 4 * (game + 1), 20), data.boards.get(PROFILE.key()).entries().size());
        }
        var top = data.boards.get(PROFILE.key()).entries();
        assertEquals("top.get(0).score() must equal 703", 703, top.get(0).score()); assertEquals("top.get(19).score() must equal 300", 300, top.get(19).score());
        assertTrue("top.stream().anyMatch(HighScores.Entry::ai) must hold", top.stream().anyMatch(HighScores.Entry::ai));
        assertTrue("top.stream().anyMatch((entry)->!entry.ai()) must hold", top.stream().anyMatch(entry -> !entry.ai()));
        var empty = new HighScores();
        empty.record(PROFILE, "negative", List.of(new HighScores.Entry("Ana", -25, false, false, "negative", 0, 0)), new Random(1));
        assertTrue("empty.boards.get(PROFILE.key()).entries().stream().anyMatch((entry)->entry.score() == -25) must hold", empty.boards.get(PROFILE.key()).entries().stream().anyMatch(entry -> entry.score() == -25));
    }

    @Test public void onlyCompletedMatchesAreCommittedAndEachSeatIsRecordedExactlyOnceAcrossReload() throws Exception {
        var disk = new Memory(); var repository = new HighScoreRepository(disk, new Random(3));
        var game = GameSession.newGame(atf.gradle.audit.GradleInputs.created("Game configuration before creation", GameConfig.newMatch(3, GameMode.LONG_ROMANIAN, AiDifficulty.NORMAL, 17, true, 10)), atf.gradle.audit.GradleInputs.created("Human name before creation", "Cristi"));

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "disk", disk, "game", game, "repository", repository);
        assertFalse("repository.record(game, 1) must remain false", repository.record(game, 1)); assertNull("disk.json remains absent", disk.json);
        finishHand(game); assertFalse("repository.record(game, 1) must remain false", repository.record(game, 1)); assertNull("disk.json remains absent", disk.json);
        while (!game.snapshot().finalHand() || game.snapshot().phase() != GamePhase.SCORE) {
            if (game.snapshot().phase() == GamePhase.SCORE) game.startNextHand();
            finishHand(game);
        }
        assertTrue("repository.record(game, 123) must hold", repository.record(game, 123));
        var board = repository.board(HighScores.Profile.from(game.config()));
        var actual = board.entries().stream().filter(entry -> !entry.sample()).toList();
        assertEquals("actual.size() must equal 3", 3, actual.size());
        var finished = game.snapshot();
        for (var player : finished.players()) {
            var entry = actual.stream().filter(value -> value.seat() == player.seat()).findFirst().orElseThrow();
            assertEquals("Entry uses the final match score", finished.matchScore(player.seat()), entry.score());
            assertEquals("entry.name() must equal player.name()", player.name(), entry.name());
            assertEquals("entry.ai() must equal !player.human()", !player.human(), entry.ai());
        }
        int writes = disk.writes;
        game.renameHuman("AltNume");
        assertFalse("new HighScoreRepository(disk, new Random(4)).record(GameSession.restoreComplete(game.saveState()), 456) must remain false", new HighScoreRepository(disk, new Random(4)).record(GameSession.restoreComplete(game.saveState()), 456));
        assertEquals("disk.writes must equal writes", writes, disk.writes); assertEquals("repository.board(HighScores.Profile.from(game.config())) must equal board", board, repository.board(HighScores.Profile.from(game.config())));
        var legacyJson = GameSessionStore.encode(game.saveState()).put("version",1);
        legacyJson.remove("history");
        var legacy = GameSessionStore.fromJson(legacyJson.toString());
        assertTrue("legacy.saveState().history().size() < legacy.snapshot().handSize() * legacy.config().playerCount() must hold", legacy.saveState().history().size() < legacy.snapshot().handSize() * legacy.config().playerCount());
        assertTrue("repository.record(\"legacy-match\", legacy, 500) must hold", repository.record("legacy-match", legacy, 500));
    }

    @Test public void finalZeroIsRecordedAsFiveHundredInItsOwnProfileAcrossReload() throws Exception {
        var config = GameConfig.newMatch(3, GameMode.ROMANIAN_WHIST, AiDifficulty.NORMAL, 4, true, 10);
        var game = GameSession.newGame(config);
        var randomBids = new Random(config.seed() ^ 0xC0FFEE);
        do {
            finishHand(game, randomBids);
            if (game.snapshot().finalHand()) break;
            game.startNextHand();
        } while (true);
        var encoded = GameSessionStore.encode(game.saveState());
        var restored = GameSessionStore.fromJson(encoded.toString());
        var disk = new Memory();
        var repository = new HighScoreRepository(disk, new Random(7));
        var profile = HighScores.Profile.from(config);
        var classicProfile = new HighScores.Profile(config.mode(), 3, AiDifficulty.NORMAL, true, 10, 10);
        atf.gradle.audit.GradleInputs.fixture("Legal completed match, score zero at seat 1",
                "config", config, "classic profile", classicProfile, "final scores", restored.snapshot().players());
        assertEquals("The checkpoint preserves the raw total", 0, restored.snapshot().players().get(1).totalScore());
        assertTrue("The checkpoint retains the match option", restored.config().allowZeroGame());
        for (var language : HowToPlay.Language.values()) {
            var copy = new WhistUiText(language);
            assertTrue("Winner copy uses 500 in either language", copy.winner(restored.snapshot()).contains("(500 "));
            assertTrue("The history legend explains the conversion", copy.zeroGameAwards(restored.snapshot()).contains("0 → 500"));
        }
        assertTrue("The first commit records the result", repository.record("zero", restored, 1));
        var reopened = new HighScoreRepository(disk, new Random(8));
        var winningEntry = reopened.board(profile).entries().get(0);
        assertEquals("The zero player wins the local ranking", 1, winningEntry.seat());
        assertEquals("The final score is 500", 500, winningEntry.score());
        assertTrue("A classic board is kept separately", reopened.board(classicProfile).entries()
                .stream().allMatch(HighScores.Entry::sample));
        assertFalse("Replaying the commit is idempotent", reopened.record("zero", restored, 2));
        encoded.put("version", 7);
        encoded.remove("allowZeroGame");
        var legacy = GameSessionStore.fromJson(encoded.toString());
        assertFalse("Legacy saves keep their original rule profile", legacy.config().allowZeroGame());
        assertEquals("A legacy zero stays zero", 0, legacy.snapshot().matchScore(1));
    }

    @Test public void failedCommitCanBeRetriedAndCorruptionIsNotOverwritten() throws Exception {
        var disk = new Memory(); var repository = new HighScoreRepository(disk, new Random(3));
        repository.boards(); String original = disk.json;
        disk.fail = true;

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "disk", disk, "original", original, "repository", repository);
        assertThrows("The operation rejects its input with IOException.class", IOException.class, () -> repository.board(PROFILE));
        assertEquals("disk.json must equal original", original, disk.json);
        disk.fail = false; assertEquals("repository.board(PROFILE).entries().size() must equal 10", 10, repository.board(PROFILE).entries().size());
        disk.json = "{broken"; int writes = disk.writes;
        assertThrows("The operation rejects its input with IOException.class", IOException.class, repository::boards);
        assertEquals("disk.json must equal \"{broken\"", "{broken", disk.json); assertEquals("disk.writes must equal writes", writes, disk.writes);
    }

    @Test public void codecRejectsUnsupportedOrDuplicateDataAndSeparatesRuleProfiles() throws Exception {
        var data = HighScores.initial(new Random(2));
        String encoded = HighScoreCodec.encode(data);

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "data", data, "encoded", encoded);
        assertEquals("HighScoreCodec.encode(HighScoreCodec.decode(encoded)) must equal encoded", encoded, HighScoreCodec.encode(HighScoreCodec.decode(encoded)));
        var oldFormat = new JSONObject(encoded).put("schemaVersion", 1);
        var profiles = oldFormat.getJSONArray("profiles");
        for (int index = 0; index < profiles.length(); index++) profiles.getJSONObject(index).remove("allowZeroGame");
        assertEquals("Version-one rankings keep their classic identities", data.boards,
                HighScoreCodec.decode(oldFormat.toString()).boards);
        var future = new JSONObject(encoded).put("schemaVersion", 99);
        assertThrows("The operation rejects its input with IOException.class", IOException.class, () -> HighScoreCodec.decode(future.toString()));
        var duplicate = new JSONObject(encoded);
        duplicate.getJSONArray("profiles").put(duplicate.getJSONArray("profiles").getJSONObject(0));
        assertThrows("The operation rejects its input with IOException.class", IOException.class, () -> HighScoreCodec.decode(duplicate.toString()));
        assertNotEquals("new HighScores.Profile(PROFILE.mode(), 3, PROFILE.difficulty(), true, 10, 10).key() must differ from PROFILE.key()", PROFILE.key(), new HighScores.Profile(PROFILE.mode(), 3, PROFILE.difficulty(), true, 10, 10).key());
        assertNotEquals("new HighScores.Profile(PROFILE.mode(), 4, AiDifficulty.NORMAL, true, 10, 10).key() must differ from PROFILE.key()", PROFILE.key(), new HighScores.Profile(PROFILE.mode(), 4, AiDifficulty.NORMAL, true, 10, 10).key());
        assertNotEquals("new HighScores.Profile(PROFILE.mode(), 4, PROFILE.difficulty(), true, 5, 5).key() must differ from PROFILE.key()", PROFILE.key(), new HighScores.Profile(PROFILE.mode(), 4, PROFILE.difficulty(), true, 5, 5).key());
        assertNotEquals("new HighScores.Profile(PROFILE.mode(), 4, PROFILE.difficulty(), true, 10, 5).key() must differ from PROFILE.key()", PROFILE.key(), new HighScores.Profile(PROFILE.mode(), 4, PROFILE.difficulty(), true, 10, 5).key());
    }

    @Test public void theLocalJsonFileCanBeReopenedWithoutAndroid() throws Exception {
        var folder = Files.createTempDirectory("whist-scores-"); var file = folder.resolve("highestScores.json");
        HighScoreRepository.Storage disk = new HighScoreRepository.Storage() {
            public String read() throws IOException { return Files.exists(file) ? new String(Files.readAllBytes(file), java.nio.charset.StandardCharsets.UTF_8) : null; }
            public void write(String json) throws IOException { Files.write(file, json.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
        };
        try {
            var before = new HighScoreRepository(disk, new Random(4)).boards();

            atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before, "disk", disk, "file", file, "folder", folder);
            assertTrue("Files.size(file) > 0 must hold", Files.size(file) > 0);
            assertEquals("new HighScoreRepository(disk, new Random(5)).boards() must equal before", before, new HighScoreRepository(disk, new Random(5)).boards());
        } finally { Files.deleteIfExists(file); Files.deleteIfExists(folder); }
    }

    @Test public void failedFinalMatchWriteIsRetryableAndTheMatchIsNotMarkedProcessedPrematurely() throws Exception {
        var disk = new Memory(); var repository = new HighScoreRepository(disk, new Random(3));
        var game = GameSession.newGame(atf.gradle.audit.GradleInputs.created("Game configuration before creation", GameConfig.newMatch(3, GameMode.ROMANIAN_WHIST, AiDifficulty.NORMAL, 19, true, 5)));
        do { finishHand(game); if (game.snapshot().finalHand()) break; game.startNextHand(); } while (true);
        var profile = HighScores.Profile.from(game.config());
        repository.board(profile);
        String before = disk.json; disk.fail = true;

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before, "disk", disk, "game", game, "profile", profile, "repository", repository);
        assertThrows("The operation rejects its input with IOException.class", IOException.class, () -> repository.record("first-match", game, 1));
        assertEquals("disk.json must equal before", before, disk.json);
        disk.fail = false;
        assertTrue("repository.record(\"first-match\", game, 1) must hold", repository.record("first-match", game, 1));
        assertFalse("repository.record(\"first-match\", game, 2) must remain false", repository.record("first-match", game, 2));
        assertEquals("repository.board(profile).entries().stream().filter((entry)->!entry.sample()).count() must equal 3", 3, repository.board(profile).entries().stream().filter(entry -> !entry.sample()).count());
        assertTrue("repository.record(\"another-match-with-the-same-deal\", game, 3) must hold", repository.record("another-match-with-the-same-deal", game, 3));
        assertEquals("repository.board(profile).entries().stream().filter((entry)->!entry.sample()).count() must equal 6", 6, repository.board(profile).entries().stream().filter(entry -> !entry.sample()).count());
    }

    private static void finishHand(GameSession game) {
        finishHand(game, null);
    }

    private static void finishHand(GameSession game, Random random) {
        while (game.snapshot().phase() == GamePhase.BIDDING) {
            var state = game.snapshot();
            var legal = GameRules.allowedBids(state.handSize(), state.bidTotal(),
                    state.bidsSubmitted() == state.players().size() - 1);
            game.submitBid(state.biddingSeat(), legal.get(random == null ? 0 : random.nextInt(legal.size())));
        }
        while (game.snapshot().phase() == GamePhase.PLAYING) {
            var state = game.snapshot(); var player = state.players().get(state.currentSeat());
            game.playCard(player.seat(), GameRules.legalCards(player.hand(), state.currentTrick().isEmpty() ? null
                    : state.currentTrick().get(0).card().suit(), state.trump(), state.mode()).get(0));
        }
    }
}
