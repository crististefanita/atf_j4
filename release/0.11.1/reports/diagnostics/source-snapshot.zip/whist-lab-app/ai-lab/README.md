# Laboratorul AI și jucătorul independent

## Pe scurt

Acest modul JVM reunește jucătorul independent, uneltele offline și experimentele AI. Sursele principale ale jucătorului rămân fără importuri din motor, Android sau ATF; experimentele au activare explicită și nu intră în artefactul principal.

[game-core/build.gradle](../game-core/build.gradle) consumă modulul prin `testImplementation project(":ai-lab")`. [POM-ul Android](../../atf-test-android/pom.xml) compilează aceleași surse numai pentru acceptanța Maven; aplicația nu depinde de laborator în APK.

## Organizarea modulului

| Zonă | Responsabilitate |
|---|---|
| [src/main/java](src/main/java/) | Modelul independent și observația permisă actorului. |
| [src/test/java](src/test/java/) | Contractele Java locale, cu poziții legale construite fără motor sau arhivă. |
| [tools](tools/README.md) | Corpus, modele, diagnostic și calificare, cu teste Node.js alăturate. |
| [experiments](experiments/) | Prototipuri și [surse alternative de licitare](experiments/bid-models/README.md), excluse din compilarea implicită. |
| [build.gradle](build.gradle) | `check` combină testele Java și Node; replay-ul extern are activare separată. |

## Intrare și informație disponibilă

[IndependentPlayer.Position](src/main/java/ro/whistlab/coach/IndependentPlayer.java) conține mâna proprie și fapte publice: numărul de cărți rămase, contractele, levatele, totalurile, seriile, cărțile jucate, levata curentă și cartea întoarsă.

Nu există câmp pentru mâinile reale ale adversarilor sau valoarea de inițializare a împărțirii. Adaptoarele trebuie să construiască această proiecție înainte de a apela AI-ul. În testele Android, această limită este aplicată de [WhistChallenger](../../atf-test-android/src/test/java/atf/android/e2e/player/WhistChallenger.java).

Cărțile numerice folosesc `13 × suit + rank - 2`, cu ordinea culorilor pică,
cupă, treflă, caro. Regula de urmărire a culorii, atuul obligatoriu, câștigătorul
și scorul sunt implementate separat de `game-core`.

## Flux și responsabilități

```mermaid
flowchart LR
OBS[Observație proprie/publică] -->|constrânge| WORLDS[Lumi fezabile]
WORLDS -->|alimentează| PLAN[RolloutPlanner]
PLAN -->|propune| MOVE[Acțiune legală]
WORLDS -->|permite verificare| CERT[ContractGuarantee]
CERT -->|poate înlocui| MOVE
```

<details>
<summary>Legendă și limite</summary>

Lumile sunt ipoteze compatibile cu informația publică. Certificarea poate înlocui propunerea numai în domeniul complet enumerat; epuizarea bugetului păstrează varianta de rezervă. Jucătorul independent rămâne suport de test separat de politica aplicației.

</details>

## Politica din sursele active

Licitarea compară punctele contractelor pe aceleași lumi ipotetice; jocul
compară punctele cărților legale, cu punctele celui mai puternic adversar drept
criteriu de departajare. Bugetele și excepția pentru posteriorul de o carte se
citesc din metodele `bid` și `card` ale sursei active. Aceasta este utilitate în
puncte, nu un certificat că licitația aleasă va fi realizată.

| Mecanism | Contract și limită |
|---|---|
| [IndependentDeals](src/main/java/ro/whistlab/coach/IndependentDeals.java) | Distribuțiile respectă cărțile publice, cartea întoarsă, necesarul și culorile demonstrate ca epuizate; varianta fezabilă de rezervă păstrează aceleași restricții. |
| [IndependentContinuations](src/main/java/ro/whistlab/coach/IndependentContinuations.java) | Avansează lumea ipotetică, levatele și scorurile. Simularea deciziei și rezolvarea exhaustivă de diagnostic sunt intrări distincte; diagnosticul nu înlocuiește politica activă. |
| [RolloutPlanner](src/main/java/ro/whistlab/coach/RolloutPlanner.java) | Modelează continuarea unei ipoteze; mâinile reale adverse nu intră în API-ul deciziei. [Referințele înghețate](../game-core/src/test/java/ro/whistlab/coach/baseline) rămân separate în testele motorului. |
| [ContractGuarantee](src/main/java/ro/whistlab/coach/ContractGuarantee.java) | Poate înlocui propunerea numai pentru universul complet și continuările legale din domeniul finit permis; enumerarea incompletă sau bugetul epuizat păstrează propunerea inițială. |

Reproductibilitatea privește aceeași intrare completă; invarianta față de schimbarea
comună a scorurilor nu este presupusă. Mecanismele nu certifică un jucător perfect.

## Verificare și experimente

Din directorul `whist-lab-app` al unei copii temporare complete a proiectului:

```powershell
.\gradlew.bat -p algorithm-build :game-core:test --tests ro.whistlab.coach.IndependentPlayerModelTest --tests ro.whistlab.core.ai.engine.CertifiedContractRegressionTest --offline --no-daemon
```

[IndependentPlayerModelTest](../game-core/src/test/java/ro/whistlab/coach/IndependentPlayerModelTest.java)
verifică generatorul de distribuții, proprietatea cărților și modelele finite.
[CertifiedContractRegressionTest](../game-core/src/test/java/ro/whistlab/core/ai/engine/CertifiedContractRegressionTest.java)
separă un certificat valid de lipsa garanției și de varianta de rezervă.

Turneele se rulează numai prin colecțiile și protocoalele explicite din [lansator](../../scripts/run-whist-collection.ps1).

Uneltele au verificare proprie, din aceeași copie temporară:

```powershell
.\gradlew.bat -p algorithm-build :ai-lab:check --offline --no-daemon
```

Păstrați separat cazurile de învățare, regresiile mici, sursa candidatului și partidele noi de evaluare. Corectitudinea unei componente sau un câștig într-o lume ipotetică nu reprezintă singure un progres al forței de joc. Alternativele externe nu schimbă sursele active și nu se promovează prin simpla trecere a unui test local.

## Verificare proprie și calificare

| Suprafață | Contract și limită |
|---|---|
| Java | [Contractele locale](src/test/java/ro/whistlab/coach/IndependentPlayerContractTest.java) verifică observația, legalitatea, determinismul, anularea și bugetele. Motorul, Android și ATF lipsesc din classpath-ul acestor teste; comparațiile din `game-core` rămân integrare. |
| Unelte Node | `check` include `testTools`; [constructorul de partide legale](tools/testing/legal-game-fixture.mjs) înlocuiește intrările implicite din arhivă. Mutațiile de carte, licitație, levată și scor verifică refuzurile validatorului. |
| Arhivă | `replayArchive` cere fișier și SHA-256 explicite; verifică octeții înaintea parsării și regulilor. Nu este dependență a `check`. |
| Expunerea datelor | [Registrul comun](../../docs/learning/ATF_EvaluationRegistry.md) coordonează rezervările între corpusuri și păstrează reutilizarea ca expunere cunoscută. |

Promovarea rămâne condiționată de progres pe partide noi și de identitatea tuturor surselor; o verificare locală reușită închide numai contractul ei. [Protocolul de învățare](../../docs/learning/README.md) deține procedura, iar [feedback-ul AI](../../docs/feedback/ATF_Ai.md) centralizează lucrările încă deschise.

[PlannerControl](src/main/java/ro/whistlab/coach/PlannerControl.java) oferă măsurare și limită de lucru opționale, izolate pe fir.

- Întreruperea păstrează marcajul și aruncă `CancellationException`; `WORK_LIMIT` abandonează decizia printr-o excepție distinctă.
- Închiderea contextului elimină limita pentru apelurile următoare.
- [Calificarea costului](../../docs/ai/ATF_CostQualification.md) separă acest control de bugetul dovezii și de forța strategică.

## Catalogul testelor

[Intrările și responsabilitățile testelor](src/test/README.md) explică selecțiile, precondițiile și interpretarea rezultatului, prin aceeași strategie comună pentru toate livrările.
