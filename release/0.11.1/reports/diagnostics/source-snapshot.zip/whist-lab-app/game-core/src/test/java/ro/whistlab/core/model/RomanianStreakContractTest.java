package ro.whistlab.core.model;
import ro.whistlab.core.testing.match.PlayerObservations;

import ro.whistlab.core.ai.engine.MonteCarloAi;
import ro.whistlab.core.config.AiDifficulty;
import ro.whistlab.core.config.GameConfig;
import ro.whistlab.core.learning.tournament.AiTrainingTournamentTest;
import ro.whistlab.core.rules.GameMode;
import ro.whistlab.core.rules.RomanianScoring;
import ro.whistlab.core.session.GamePhase;
import ro.whistlab.core.session.GameSession;

import static atf.gradle.audit.assertions.GradleAssertions.*;
import java.util.*;
import org.junit.Test;
import ro.whistlab.coach.IndependentPlayer;

/** Compatibility contract for retained asymmetric profiles; symmetric games have their own component suite. */
public class RomanianStreakContractTest extends atf.gradle.audit.GradleAuditedTest {
    @Test public void rs01OriginalFifthExactContractAddsFiveAndResets(){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "declared constant 1", 7, "declared constant 2", 5, "declared constant 3", 0, "declared constant 4", 2, "declared constant 5", 3, "declared constant 6", 4);
assertEquals("RomanianScoring.score(2, 2, 3, 4, 5) must equal new RomanianScoring.Result(7, 5, 0)", new RomanianScoring.Result(7,5,0),RomanianScoring.score(2,2,3,4,5));}
    @Test public void rs02SelectedTenReplacesOnlyThePositiveSeriesReward(){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "declared constant 1", 7, "declared constant 2", 10, "declared constant 3", 0, "declared constant 4", 2, "declared constant 5", 3, "declared constant 6", 4, "declared constant 7", -2, "declared constant 8", -5, "declared constant 9", -4);
assertEquals("RomanianScoring.score(2, 2, 3, 4, 10) must equal new RomanianScoring.Result(7, 10, 0)", new RomanianScoring.Result(7,10,0),RomanianScoring.score(2,2,3,4,10));assertEquals("RomanianScoring.score(0, 2, 3, -4, 10) must equal new RomanianScoring.Result(-2, -5, 0)", new RomanianScoring.Result(-2,-5,0),RomanianScoring.score(0,2,3,-4,10));}
    @Test public void rs03FirstFourExactContractsNeverReceiveAPrematureBonus(){for(int value:List.of(5,10))for(int before=0;before<4;before++){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before, "value", value);
assertEquals("RomanianScoring.score(0, 0, 2, before, value) must equal new RomanianScoring.Result(5, 0, before + 1)", new RomanianScoring.Result(5,0,before+1),RomanianScoring.score(0,0,2,before,value)); }}
    @Test public void rs04BothUnderbidAndOverbidCountAsMissedContracts(){for(int value:List.of(5,10))for(int before=-4;before<=0;before++)for(int won:List.of(0,2)){var r=RomanianScoring.score(won,1,2,before,value);
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before, "r", r, "value", value, "won", won);
assertEquals("r.basePoints() must equal -1", -1,r.basePoints());assertEquals("r.streakPoints() must equal before == -4 ? -5 : 0", before==-4?-5:0,r.streakPoints());assertEquals("r.nextStreak() must equal before == -4 ? 0 : before - 1", before==-4?0:before-1,r.nextStreak());}}
    @Test public void rs05ExactZeroCountsAsWinningAContractEvenIfAnotherPlayerTakesAllTricks(){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "declared constant 1", 5, "declared constant 2", 10, "declared constant 3", 0, "declared constant 4", 8, "declared constant 5", 4);
assertEquals("RomanianScoring.score(0, 0, 8, 4, 10) must equal new RomanianScoring.Result(5, 10, 0)", new RomanianScoring.Result(5,10,0),RomanianScoring.score(0,0,8,4,10));}
    @Test public void rs06OppositeEligibleOutcomeStartsANewSeriesAtOne(){for(int before=1;before<=4;before++){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before);
assertEquals("RomanianScoring.score(0, 1, 2, before).nextStreak() must equal -1", -1,RomanianScoring.score(0,1,2,before).nextStreak()); }for(int before=-4;before<0;before++)assertEquals("RomanianScoring.score(0, 0, 2, before).nextStreak() must equal 1", 1,RomanianScoring.score(0,0,2,before).nextStreak());}
    @Test public void rs07OneCardExactDoesNotAdvanceAWinningSeries(){for(int before=0;before<=4;before++)for(int won=0;won<=1;won++){var r=RomanianScoring.score(won,won,1,before,10);
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before, "r", r, "won", won);
assertEquals("r.nextStreak() must equal before", before,r.nextStreak());assertEquals("r.streakPoints() must equal 0", 0,r.streakPoints());}}
    @Test public void rs08OneCardMissDoesNotAdvanceALosingSeries(){for(int before=-4;before<=0;before++){var r=RomanianScoring.score(1,0,1,before,10);
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before, "r", r);
assertEquals("r.nextStreak() must equal before", before,r.nextStreak());assertEquals("r.streakPoints() must equal 0", 0,r.streakPoints());}}
    @Test public void rs09OppositeOneCardOutcomeBreaksEitherSeriesWithoutStartingAnother(){for(int before=1;before<=4;before++){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "before", before);
assertEquals("RomanianScoring.score(0, 1, 1, before).nextStreak() must equal 0", 0,RomanianScoring.score(0,1,1,before).nextStreak()); }for(int before=-4;before<0;before++)assertEquals("RomanianScoring.score(0, 0, 1, before).nextStreak() must equal 0", 0,RomanianScoring.score(0,0,1,before).nextStreak());}
    @Test public void rs10TheTenthMatchingEligibleResultAwardsASecondBonus(){for(int value:List.of(5,10)){int streak=0,total=0;for(int i=1;i<=10;i++){var r=RomanianScoring.score(0,0,2,streak,value);
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "i", i, "r", r, "streak", streak, "total", total, "value", value);
assertEquals("r.streakPoints() must equal i % 5 == 0 ? value : 0", i%5==0?value:0,r.streakPoints());streak=r.nextStreak();total+=r.totalPoints();}assertEquals("total must equal 50 + 2 * value", 50+2*value,total);assertEquals("streak must equal 0", 0,streak);}}
    @Test public void rs11AllPriorCountersAndLegalBidWonPairsMatchAnIndependentTwoCounterOracle()throws Exception{
        atf.gradle.audit.GradleInputs.fixture("Independent scoring oracle domain", "positive rewards", List.of(5, 10),
                "hand sizes inclusive", List.of(1, 8), "previous counters inclusive", List.of(-4, 4),
                "bid and won inclusive", "0..hand size", "expected combinations", 5112);
        var checks = new atf.gradle.audit.matrix.ExhaustiveMatrixChecks();
        var evidence=new StringBuilder("size\tbid\twon\tprevious\tpositiveReward\texpectedBase\tactualBase\texpectedSeries\tactualSeries\texpectedNext\tactualNext\tpassed\n");
        int combinations=0;try{for(int value:List.of(5,10))for(int size=1;size<=8;size++)for(int before=-4;before<=4;before++)for(int bid=0;bid<=size;bid++)for(int won=0;won<=size;won++){
            int wins=Math.max(before,0),losses=Math.max(-before,0),base;
            if(won==bid){base=bid+5;losses=0;if(size>1)wins++;}else{base=-Math.abs(bid-won);wins=0;if(size>1)losses++;}
            int extra=0;if(wins==5){extra=value;wins=0;}if(losses==5){extra=-5;losses=0;}
            var expected=new RomanianScoring.Result(base,extra,wins-losses);var actual=RomanianScoring.score(won,bid,size,before,value);
            evidence.append(size).append('\t').append(bid).append('\t').append(won).append('\t').append(before).append('\t').append(value).append('\t').append(base).append('\t').append(actual.basePoints()).append('\t').append(extra).append('\t').append(actual.streakPoints()).append('\t').append(wins-losses).append('\t').append(actual.nextStreak()).append('\t').append(expected.equals(actual)).append('\n');

            checks.at("size=" + size + ", bid=" + bid + ", won=" + won + ", previous=" + before + ", reward=" + value);
            checks.equal("Scoring result equals the independent two-counter oracle", expected, actual);
            combinations++;
        }
            assertEquals("Every legal scoring combination was evaluated", 5112, combinations);
            assertEquals("Every combination supplied one independent comparison", 5112L, checks.checkedPairs());
            checks.publish();
        }finally{evidence("series-domain.tsv",evidence.toString());}
    }
    @Test public void rs12ImpossibleHandResultsCountersAndRewardValuesAreRejected(){
        for(int size:List.of(-1,0,9)){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "size", size);
assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->RomanianScoring.score(0,0,size,0)); }
        for(int bad:List.of(-1,3)){assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->RomanianScoring.score(bad,0,2,0));assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->RomanianScoring.score(0,bad,2,0));}
        for(int bad:List.of(-5,5))assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->RomanianScoring.score(0,0,2,bad));
        for(int bad:List.of(-5,0,6,15))assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->RomanianScoring.score(0,0,2,0,bad));
    }
    @Test public void rs13ClassicCompatibilityAndNewMenuDefaultAreExplicit(){var classic=new GameConfig(4,GameMode.ROMANIAN_WHIST,AiDifficulty.EXPERT,1);
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "classic", classic);
assertFalse("classic.streakBonuses() must remain false", classic.streakBonuses());assertEquals("classic.streakBonusPoints() must equal 5", 5,classic.streakBonusPoints());var selected=new GameConfig(4,GameMode.ROMANIAN_WHIST,AiDifficulty.EXPERT,1,true);assertTrue("selected.streakBonuses() must hold", selected.streakBonuses());assertEquals("selected.streakBonusPoints() must equal 10", 10,selected.streakBonusPoints());}
    @Test public void rs14SeriesAreRejectedForUnrelatedModesAndInvalidRewardOptions(){for(GameMode mode:GameMode.values())if(!mode.isRomanian()){
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "mode", mode);
assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->new GameConfig(4,mode,AiDifficulty.NORMAL,1,true,10)); }for(int bad:List.of(0,6,20))assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->new GameConfig(4,GameMode.ROMANIAN_WHIST,AiDifficulty.NORMAL,1,true,bad));}
    @Test public void rs15EngineAppliesConfiguredBonusesOnlyOnTheFinalCardAndPreservesThemAcrossResume()throws Exception{for(int value:List.of(5,10)){
        var game=fixture(value,true,new int[]{4,4,-4,-4});String input=game.snapshot().toString();while(game.snapshot().phase()==GamePhase.BIDDING){int s=game.snapshot().biddingSeat();game.submitBid(s,new int[]{2,0,0,1}[s]);}
        for(int i=0;i<8;i++){var s=game.snapshot();
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "game", game, "i", i, "input", input, "s", s, "value", value);
assertTrue("s.players().stream().allMatch((p)->p.totalScore() == 0) must hold", s.players().stream().allMatch(p->p.totalScore()==0));game.playCard(s.currentSeat(),s.players().get(s.currentSeat()).hand().get(0));if(i==6)game=GameSession.restoreComplete(game.saveState());}
        assertEquals("game.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList() must equal List.of(7 + value, 5 + value, 5, -6)", List.of(7+value,5+value,5,-6),game.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList());
        var ledger = GameSession.restoreComplete(game.saveState()).scoreHistory();
        for (int seat = 0; seat < 4; seat++) {
            int earned = List.of(7 + value, 5 + value, 5, -6).get(seat);
            assertEquals("ledger.points(20, seat) must equal earned", earned, ledger.points(20, seat));
            assertEquals("ledger.total(20, seat) must equal earned", earned, ledger.total(20, seat));
        }
        assertEquals("game.snapshot().players().stream().map(GameSession.PlayerSnapshot::streak).toList() must equal List.of(0, 0, 1, 0)", List.of(0,0,1,0),game.snapshot().players().stream().map(GameSession.PlayerSnapshot::streak).toList());
        assertEquals("game.snapshot().players().stream().map(GameSession.PlayerSnapshot::streakPoints).toList() must equal List.of(value, value, 0, -5)", List.of(value,value,0,-5),game.snapshot().players().stream().map(GameSession.PlayerSnapshot::streakPoints).toList());
        var complete=game.snapshot();game=GameSession.restoreComplete(game.saveState());assertEquals("game.snapshot() must equal complete", complete,game.snapshot());var scored=game;assertThrows("The operation rejects its input with IllegalStateException.class", IllegalStateException.class,()->scored.playCard(0,new Card(Suit.HEARTS,14)));assertEquals("game.snapshot() must equal complete", complete,game.snapshot());
        game.startNextHand();assertEquals("game.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList() must equal complete.players().stream().map(GameSession.PlayerSnapshot::totalScore).toList()", complete.players().stream().map(GameSession.PlayerSnapshot::totalScore).toList(),game.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList());assertTrue("game.snapshot().players().stream().allMatch((p)->p.streakPoints() == 0) must hold", game.snapshot().players().stream().allMatch(p->p.streakPoints()==0));assertEquals("game.config().streakBonusPoints() must equal value", value,game.config().streakBonusPoints());
        evidence("series-integration-"+value+".txt","Controlled component boundary, not a normal UI game.\nINPUT: "+input+"\nBIDS: [2,0,0,1]\nEXPECTED WON: [2,0,0,0]\nEXPECTED TOTALS: "+List.of(7+value,5+value,5,-6)+"\nEXPECTED COUNTERS: [0,0,1,0]\nEXPECTED SERIES POINTS: "+List.of(value,value,0,-5)+"\nACTUAL SCORED STATE (also identical after checkpoint restore): "+complete+"\nACTUAL NEXT HAND (same totals, cleared awarded points): "+game.snapshot()+"\nAll assertions PASS.\n");
    }}
    @Test public void rs16DisablingSeriesPreservesClassicScores(){var g=fixture(10,false,new int[]{0,0,0,0});while(g.snapshot().phase()==GamePhase.BIDDING){int s=g.snapshot().biddingSeat();g.submitBid(s,new int[]{2,0,0,1}[s]);}while(g.snapshot().phase()==GamePhase.PLAYING){var s=g.snapshot();g.playCard(s.currentSeat(),s.players().get(s.currentSeat()).hand().get(0));}
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "g", g);
assertEquals("g.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList() must equal List.of(7, 5, 5, -1)", List.of(7,5,5,-1),g.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList());}
    @Test public void rs17ExpertUtilityIncludesTheSelectedRewardAndFixedPenalty(){for(int value:List.of(5,10)){var g=fixture(value,true,new int[]{4,-4,0,0});var v=MonteCarloAi.observe(g.snapshot(),0);
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "g", g, "v", v, "value", value);
assertEquals("MonteCarloAi.points(v, 0, 2, 2) must equal 7 + value", 7+value,MonteCarloAi.points(v,0,2,2));assertEquals("MonteCarloAi.points(v, 1, 0, 1) must equal -6", -6,MonteCarloAi.points(v,1,0,1));assertEquals("MonteCarloAi.points(v, 2, 0, 0) must equal 5", 5,MonteCarloAi.points(v,2,0,0));}}
    @Test public void rs18LegacyIndependentPlannerHashesRemainIdenticalForClassicInputs(){
        var seats=List.of(new IndependentPlayer.Seat(2,null,0,10),new IndependentPlayer.Seat(2,1,0,-2),new IndependentPlayer.Seat(2,0,0,0));
        var oldSeats=seats.stream().map(s->new V1Seat(s.remaining(),s.bid(),s.won(),s.total())).toList();
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "oldSeats", oldSeats, "seats", seats);
assertEquals("seats.hashCode() must equal oldSeats.hashCode()", oldSeats.hashCode(),seats.hashCode());
        var p=new IndependentPlayer.Position(0,2,2,0,List.of(5,18),seats,List.of(),List.of(),6);
        assertEquals("p.hashCode() must equal new V1Position(0, 2, 2, 0, List.of(5, 18), oldSeats, List.of(), List.of(), 6).hashCode()", new V1Position(0,2,2,0,List.of(5,18),oldSeats,List.of(),List.of(),6).hashCode(),p.hashCode());
    }
    private record V1Seat(int remaining,Integer bid,int won,int total) { }
    private record V1Position(int seat,int dealer,int size,int trump,List<Integer> hand,List<V1Seat> seats,List<IndependentPlayer.Play> trick,List<IndependentPlayer.Play> history,int turnedCard) { }
    @Test public void rs19CheckpointsRejectOutOfRangeSeriesCounters(){for(int bad:List.of(-5,5)){var saved=fixture(10,true,new int[]{0,0,0,0}).saveState();
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "bad", bad, "saved", saved);
assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(saved,0,bad,0)));}}
    @Test public void rs20BonusCannotAppearBeforeScoringOrWhenDisabled(){var enabled=fixture(10,true,new int[]{4,0,0,0}).saveState();
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "enabled", enabled);
assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(enabled,0,0,10)));var classic=fixture(10,false,new int[]{0,0,0,0}).saveState();assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(classic,0,1,0)));}
    @Test public void rs21BonusSignAndCounterMustMatchTheCompletedContract(){var g=fixture(10,true,new int[]{0,0,0,0});while(g.snapshot().phase()==GamePhase.BIDDING){int s=g.snapshot().biddingSeat();g.submitBid(s,new int[]{2,0,0,1}[s]);}while(g.snapshot().phase()==GamePhase.PLAYING){var s=g.snapshot();g.playCard(s.currentSeat(),s.players().get(s.currentSeat()).hand().get(0));}var scored=g.saveState();
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "g", g, "scored", scored);
assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(scored,3,0,10)));assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(scored,0,0,-5)));assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(scored,0,1,10)));assertThrows("The operation rejects its input with IllegalArgumentException.class", IllegalArgumentException.class,()->GameSession.restoreComplete(change(scored,0,-1,0)));}
    @Test public void rs22ActualOneCardHandPreservesMatchingStreaksAndClearsOppositeStreaks(){
        var config=new GameConfig(4,GameMode.ROMANIAN_WHIST,AiDifficulty.NORMAL,12,true,10);
        var dealt=GameSession.fromDeal(config,List.of(List.of(c(14)),List.of(c(13)),List.of(c(12)),List.of(c(11))),Trump.NO_TRUMP,3).saveState();
        var g=GameSession.restoreComplete(change(change(change(change(dealt,0,4,0),1,-4,0),2,4,0),3,-4,0));
        for(int seat=0;seat<4;seat++)g.submitBid(seat,new int[]{1,0,0,1}[seat]);for(int seat=0;seat<4;seat++)g.playCard(seat,c(14-seat));

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "config", config, "dealt", dealt, "g", g);
        assertEquals("g.snapshot().players().stream().map(GameSession.PlayerSnapshot::streak).toList() must equal List.of(4, 0, 4, -4)", List.of(4,0,4,-4),g.snapshot().players().stream().map(GameSession.PlayerSnapshot::streak).toList());assertEquals("g.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList() must equal List.of(6, 5, 5, -1)", List.of(6,5,5,-1),g.snapshot().players().stream().map(GameSession.PlayerSnapshot::totalScore).toList());assertTrue("g.snapshot().players().stream().allMatch((p)->p.streakPoints() == 0) must hold", g.snapshot().players().stream().allMatch(p->p.streakPoints()==0));assertEquals("GameSession.restoreComplete(g.saveState()).snapshot() must equal g.snapshot()", g.snapshot(),GameSession.restoreComplete(g.saveState()).snapshot());
    }
    @Test public void rs23ChangingOnlyAnInapplicableSeriesRewardDoesNotChangeBeliefsOrDecisions(){
        var five=fixture(5,true,new int[]{0,0,0,0});var ten=fixture(10,true,new int[]{0,0,0,0});
        for(int seat=0;seat<4;seat++){five.submitBid(seat,new int[]{2,0,0,1}[seat]);ten.submitBid(seat,new int[]{2,0,0,1}[seat]);}

        atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "five", five, "ten", ten);
        assertEquals("MonteCarloAi.chooseCard(MonteCarloAi.observe(ten.snapshot(), 0)) must equal MonteCarloAi.chooseCard(MonteCarloAi.observe(five.snapshot(), 0))", MonteCarloAi.chooseCard(MonteCarloAi.observe(five.snapshot(),0)),MonteCarloAi.chooseCard(MonteCarloAi.observe(ten.snapshot(),0)));
        var a=PlayerObservations.independent(five.snapshot(),0);var b=PlayerObservations.independent(ten.snapshot(),0);assertEquals("IndependentPlayer.card(b) must equal IndependentPlayer.card(a)", IndependentPlayer.card(a),IndependentPlayer.card(b));
    }
    @Test public void rs24BothExpertAndIndependentPlannerBidTheForcedTwoTrickContractWithEitherSeriesReward(){
        for(int value:List.of(5,10)){var g=fixture(value,true,new int[]{4,0,0,0});
atf.gradle.audit.GradleInputs.fixture("Fixture before first assertion", "g", g, "value", value);
assertEquals("MonteCarloAi.chooseBid(MonteCarloAi.observe(g.snapshot(), 0)) must equal 2", 2,MonteCarloAi.chooseBid(MonteCarloAi.observe(g.snapshot(),0)));assertEquals("IndependentPlayer.bid(PlayerObservations.independent(g.snapshot(), 0)).value() must equal 2", 2,IndependentPlayer.bid(PlayerObservations.independent(g.snapshot(),0)).value());}
    }
    private static GameSession.SaveState change(GameSession.SaveState s,int seat,int streak,int bonus){var players=new ArrayList<>(s.players());var p=players.get(seat);players.set(seat,new GameSession.PlayerState(p.seat(),p.name(),p.human(),p.hand(),p.bid(),p.tricksWon(),p.totalScore(),streak,bonus));return new GameSession.SaveState(s.config(),s.phase(),s.handIndex(),s.handSize(),s.dealerSeat(),s.biddingSeat(),s.currentSeat(),s.bidsSubmitted(),s.bidTotal(),s.trump(),s.lastTrickWinnerSeat(),players,s.currentTrick(),s.lastTrick(),s.history(),s.turnedCard());}
    private static GameSession fixture(int value,boolean enabled,int[] streaks){
        var config=new GameConfig(4,GameMode.ROMANIAN_WHIST,AiDifficulty.EXPERT,11,enabled,value,5);
        var deal=GameSession.fromDeal(config,List.of(List.of(new Card(Suit.SPADES,14),new Card(Suit.SPADES,13)),List.of(c(12),c(11)),List.of(c(10),c(9)),List.of(c(8),c(7))),Trump.SPADES,3).saveState();
        var players=deal.players().stream().map(p->new GameSession.PlayerState(p.seat(),p.name(),p.human(),p.hand(),p.bid(),p.tricksWon(),p.totalScore(),streaks[p.seat()],0)).toList();
        return GameSession.restoreComplete(new GameSession.SaveState(config,deal.phase(),19,2,deal.dealerSeat(),deal.biddingSeat(),deal.currentSeat(),0,0,deal.trump(),-1,players,List.of(),List.of(),List.of(),new Card(Suit.SPADES,7)));
    }
    private static void evidence(String name,String value)throws Exception{String out=System.getProperty("whist.componentEvidence","");if(!out.isBlank()){var folder=java.nio.file.Path.of(out);java.nio.file.Files.createDirectories(folder);java.nio.file.Files.writeString(folder.resolve(name),value);}}
    private static Card c(int rank){return new Card(Suit.HEARTS,rank);}
}
