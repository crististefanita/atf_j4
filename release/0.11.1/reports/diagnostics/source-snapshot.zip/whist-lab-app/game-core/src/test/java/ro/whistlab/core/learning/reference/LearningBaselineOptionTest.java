package ro.whistlab.core.learning.reference;

import ro.whistlab.core.learning.evaluation.RoundElevenTournamentTest;
import ro.whistlab.core.testing.CapturedRegression;import java.util.*;import org.junit.Test;
public class LearningBaselineOptionTest extends atf.gradle.audit.GradleAuditedTest {
 @Test public void aMissingOptionResolvesToTheDeclaredPlayerAndOtherVersionsAreRejected()throws Exception{CapturedRegression.run("learning-baseline-option",getClass().getName(),"aMissingOptionResolvesToTheDeclaredPlayerAndOtherVersionsAreRejected",Map.of("purpose","Prevent an empty Gradle option from changing the reference player","rule","Round11 defaults missing/blank to accepted PLAYER_V8 and rejects other baseline names before games start.","blankInput","","explicitInput","PLAYER_V8"),c->{c.equal("Blank resolves toV8","PLAYER_V8",RoundElevenTournamentTest.playerBaseline(""));c.equal("ExplicitV8 is preserved","PLAYER_V8",RoundElevenTournamentTest.playerBaseline("PLAYER_V8"));boolean rejected=false;try{RoundElevenTournamentTest.playerBaseline("PLAYER_V6");}catch(IllegalArgumentException expected){rejected=true;}c.equal("Another baseline is rejected",true,rejected);});}
}
