package ro.whistlab.core.ai.information;
import ro.whistlab.core.testing.match.PlayerObservations;

import ro.whistlab.core.ai.engine.MonteCarloAi;
import ro.whistlab.core.ai.policy.LostGameContractRegressionTest;
import ro.whistlab.core.learning.mining.LossMiningTest;
import ro.whistlab.core.learning.regression.RolloutPolicyRegressionTest;
import ro.whistlab.core.model.PlayedCard;
import ro.whistlab.core.model.Trump;
import ro.whistlab.core.rules.GameMode;
import ro.whistlab.core.testing.CapturedRegression;import java.util.*;import org.junit.Test;import ro.whistlab.coach.WorldEnumerationProbe;
public class EnumerationBudgetTest extends atf.gradle.audit.GradleAuditedTest {
 @Test public void anOverBudgetSpaceFallsBackCompletelyInsteadOfKeepingTheFirst256()throws Exception{var history=new ArrayList<PlayedCard>();for(String[] round:new String[][]{{"AS","7S","8S","9S"},{"KS","10S","JS","QS"},{"AH","7H","8H","9H"},{"KH","10H","JH","QH"},{"AC","7C","8C","9C"}})for(int s=0;s<4;s++)history.add(new PlayedCard(s,LossMiningTest.card(round[s])));var v=new MonteCarloAi.View(GameMode.ROMANIAN_WHIST,Trump.DIAMONDS,0,3,7,RolloutPolicyRegressionTest.hand("AD","KD"),List.of(new MonteCarloAi.Seat(2,7,5),new MonteCarloAi.Seat(2,0,0),new MonteCarloAi.Seat(2,0,0),new MonteCarloAi.Seat(2,1,0)),List.of(),history,LossMiningTest.card("7D"),true,10);
 CapturedRegression.run("world-budget-complete-fallback",getClass().getName(),"anOverBudgetSpaceFallsBackCompletelyInsteadOfKeepingTheFirst256",Map.of("purpose","Prevent false exhaustive confidence from a truncated prefix","rule","Nine unknown cards fill three unordered2card hands, leaving3undealt: C(9,2)*C(7,2)*C(5,2)=7560worlds. Since this exceeds256, both planners must return no exhaustive set and use their original sampled path.","before",v,"completeWorldCount",7560,"worldBudget",256),c->{c.equal("Actual unknown pool is9",9,MonteCarloAi.unknownCards(v).size());c.equal("Core discards every partial enumerated prefix",true,MonteCarloAi.enumerateSmallDeals(v).isEmpty());c.equal("Independent discards every partial enumerated prefix",true,WorldEnumerationProbe.enumerate(PlayerObservations.independent(v)).isEmpty());});}
}
